<div class="cta">
	<h3><?php _e('Plugin Configurations', 'ajax-load-more'); ?></h3>
	<div class="item">
	   <h4><?php _e('Plugin Version', 'ajax-load-more'); ?></h4>
	   <?php
	    echo '<p>'. ALM_VERSION .'</p>';
	 ?>
	</div>
	<div class="item">
	   <h4><?php _e('Release Date', 'ajax-load-more'); ?></h4>
	   <?php
	    echo '<p>'. ALM_RELEASE .'</p>';
	 ?>
	</div>
</div>